from django.apps import AppConfig


class GrupoFamiliarConfig(AppConfig):
    name = 'grupo_familiar'
