from django.apps import AppConfig


class ViviendaConfig(AppConfig):
    name = 'vivienda'
